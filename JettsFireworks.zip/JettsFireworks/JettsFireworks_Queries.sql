-- This query selects all fireworks that cost more than 50$. 
-- This does work and returns the corect items
-- Example (1, American Thunder, Multi-Shot Aerial, 89.99, 36-shot cake with red, white, and blue bursts, Class C)
Select * from jettsfireworks.Fireworks
Where Price > 50;

-- This query selects all orders and gives the name of the customer along with the employee who made the sale
-- This works correctly
-- Example (1, John Smith, Alex Johnson, 2024-06-15, 156.97)
Select Orders.OrderId, Customers.Name AS CustomerName, Employees.Name AS EmployeeName, Orders.OrderDate, Orders.TotalCost
From Orders
Join Customers ON Orders.Customers_CustomerID = Customers.CustomerID
Join Employees ON Orders.Employees_EmployeeID = Employees.EmployeeID;


-- This query Selects all fireworks that are stored in Class B bunkers
-- This works correctly
-- Example (6, Red Peony, Shell)
Select FireworksID, Name, Type
From Fireworks
Where FireworksID in (
	Select Fireworks_FireworksID
    From Inventory
    Where Bunkers_BunkerID in (
		Select BunkerID
        From Bunkers
        Where ClassStored = 'Class B'
	)
);

-- This query selects the total amount sold for each firework
-- This works
-- Example(1, 50)
Select Fireworks_FireworksID, SUM(Quantity) As AmountSold
From OrderItems
Group By Fireworks_FireworksID;


-- This query adds Customer Jett into the customer Table
-- This works
-- Example When searched for (31, individual, Jett Nehls, jettnehls@gmail.com 
Insert into Customers (CustomerType, Name, ContactInfo)
Values('individual', 'Jett Nehls', 'jettnehls@gmail.com');
Select * from Customers
Where name = 'Jett Nehls';

-- This query removes an customer with the ID of 31
-- this works
-- returns a customer column with null
Delete from Customers
Where CustomerID = 34;
Select * from Customers
Where name = 'Jett Nehls';

-- This query updates the customer ID 30 to 99 accross the tables that use a customers ID
-- This Works
-- Example (45, 99, 9, 2024-07-29,234.94)
Update Customers
Set CustomerID = 99
where CustomerId = 30;
Select * from Orders
Where Customers_CustomerID = 99;

-- This query demonstrates the constraint that we are not able to delete customers
-- this gives the constraint error
-- Error (Cannot delete or update a parent row: a foreign key constaint fails)
Delete From Customers
Where CustomerId = 10;
Select * from Customers
Where CustomerId = 10;
Select * from Orders
Where Customers_CustomerId = 10;

