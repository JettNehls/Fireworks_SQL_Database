-- MySQL dump 10.13  Distrib 8.0.43, for macos15 (arm64)
--
-- Host: localhost    Database: jettsfireworks
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Bunkers`
--

DROP TABLE IF EXISTS `Bunkers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Bunkers` (
  `BunkerID` int unsigned NOT NULL AUTO_INCREMENT,
  `ClassStored` varchar(45) NOT NULL,
  `Label` varchar(45) NOT NULL,
  PRIMARY KEY (`BunkerID`),
  UNIQUE KEY `BunkerID_UNIQUE` (`BunkerID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bunkers`
--

LOCK TABLES `Bunkers` WRITE;
/*!40000 ALTER TABLE `Bunkers` DISABLE KEYS */;
INSERT INTO `Bunkers` VALUES (1,'Class C','Bunker 1'),(2,'Class C','Bunker 2'),(3,'Class B','Pro Bunker 1'),(4,'Class C','Bunker 3'),(5,'Class B','Pro Bunker 2'),(6,'Class C','Bunker 4'),(7,'Class B','Pro Bunker 3'),(8,'Class C','Bunker 5'),(9,'Class C','Bunker 6'),(10,'Class B','Pro Bunker 4'),(11,'Class C','Bunker 7'),(12,'Class C','Bunker 8'),(13,'Class B','Pro Bunker 5'),(14,'Class C','Bunker 9'),(15,'Class C','Bunker 10'),(16,'Class B','Pro Bunker 6'),(17,'Class C','Bunker 11'),(18,'Class C','Bunker 12'),(19,'Class B','Pro Bunker 7'),(20,'Class C','Bunker 13'),(21,'Class C','Bunker 14'),(22,'Class B','Pro Bunker 8'),(23,'Class C','Bunker 15'),(24,'Class B','Pro Bunker 9'),(25,'Class C','Bunker 16');
/*!40000 ALTER TABLE `Bunkers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customers`
--

DROP TABLE IF EXISTS `Customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Customers` (
  `CustomerID` int unsigned NOT NULL AUTO_INCREMENT,
  `CustomerType` enum('individual','Wholesale') NOT NULL,
  `Name` varchar(45) NOT NULL,
  `ContactInfo` varchar(45) NOT NULL,
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `idCustomers_UNIQUE` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customers`
--

LOCK TABLES `Customers` WRITE;
/*!40000 ALTER TABLE `Customers` DISABLE KEYS */;
INSERT INTO `Customers` VALUES (1,'individual','John Smith','john.smith@email.com'),(2,'individual','Sarah Johnson','sarah.j@email.com'),(3,'Wholesale','Party City Wholesale','orders@partycity.com'),(4,'individual','Michael Brown','mike.brown@email.com'),(5,'individual','Emily Davis','emily.davis@email.com'),(6,'Wholesale','Fireworks Unlimited','wholesale@fireworksunlimited.com'),(7,'individual','David Wilson','david.w@email.com'),(8,'individual','Jennifer Lee','jlee@email.com'),(9,'individual','Robert Taylor','rtaylor@email.com'),(10,'Wholesale','Red Apple Fireworks','sales@redapplefireworks.com'),(11,'individual','Patricia Moore','pmoore@email.com'),(12,'individual','James Anderson','janderson@email.com'),(13,'individual','Linda Thomas','l.thomas@email.com'),(14,'individual','William Jackson','w.jackson@email.com'),(15,'individual','Elizabeth White','e.white@email.com'),(16,'Wholesale','Bang Boom Distributors','sales@bangboom.com'),(17,'individual','Charles Harris','charles.h@email.com'),(18,'individual','Susan Martin','s.martin@email.com'),(19,'individual','Joseph Thompson','j.thompson@emaail.com'),(20,'individual','Karen Garcia','k.garcia@email.com'),(21,'individual','Thomas Martinez','t.martinez@email.com'),(22,'individual','Nancy Robinson','n.robinson@email.com'),(23,'individual','Christopher Clark','c.clark@email.com'),(24,'individual','Margaret Rodriguez','m.rodriguez@email.com'),(25,'Wholesale','Independence Pyro','sales@independencepyro.com'),(26,'individual','Brian Lewis','b.lewis@email.com'),(27,'individual','Lisa Walker','l.walker@email.com'),(28,'Wholesale','Patriot Fireworks Co.','orders@patriotfireworks.com'),(29,'individual','Daniel Hall','d.hall@email.com'),(99,'individual','Michelle Allen','m.allen@email.com');
/*!40000 ALTER TABLE `Customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employees`
--

DROP TABLE IF EXISTS `Employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Employees` (
  `EmployeeID` int unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `EmploymentType` enum('Full Time','Contracted') NOT NULL,
  `Role` varchar(100) NOT NULL,
  `ContactInfo` varchar(200) NOT NULL,
  PRIMARY KEY (`EmployeeID`),
  UNIQUE KEY `EmployeeID_UNIQUE` (`EmployeeID`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employees`
--

LOCK TABLES `Employees` WRITE;
/*!40000 ALTER TABLE `Employees` DISABLE KEYS */;
INSERT INTO `Employees` VALUES (1,'Alex Johnson','Full Time','Sales Manager','alex.j@jettsfireworks.com'),(2,'Maria Garcia','Full Time','Sales Associate','maria.g@jettsfireworks.com'),(3,'Samuel Chen','Contracted','Inventory Specialist','sam.chen@jettsfireworks.com'),(4,'Robert Williams','Full Time','Warehouse Manager','r.williams@jettsfireworks.com'),(5,'Patricia Miller','Full Time','Sales Associate','p.miller@jettsfireworks.com'),(6,'James Davis','Contracted','Safety Officer','j.davis@jettsfireworks.com'),(7,'Jennifer Wilson','Full Time','Office Manager','j.wilson@jettsfireworks.com'),(8,'Michael Moore','Full Time','Sales Associate','m.moore@jettsfireworks.com'),(9,'Linda Taylor','Full Time','Customer Service','l.taylor@jettsfireworks.com'),(10,'William Anderson','Contracted','Warehouse Staff','w.anderson@jettsfireworks.com'),(11,'Barbara Thomas','Full Time','Sales Associate','b.thomas@jettsfireworks.com'),(12,'Richard Jackson','Full Time','Senior Sales','r.jackson@jettsfireworks.com'),(13,'Jessica White','Contracted','Inventory Assistant','j.white@jettsfireworks.com'),(14,'Charles Harris','Full Time','Sales Manager','c.harris@jettsfireworks.com'),(15,'Susan Martin','Full Time','Administrator','s.martin@jettsfireworks.com'),(16,'Joseph Thompson','Contracted','Warehouse Staff','j.thompson@jettsfireworks.com'),(17,'Karen Garcia','Full Time','Sales Associate','k.garcia@jettsfireworks.com'),(18,'Thomas Martinez','Full Time','Customer Service','t.martinez@jettsfireworks.com'),(19,'Nancy Robinson','Contracted','Safety Assistant','n.robinson@jettsfireworks.com'),(20,'Christopher Clark','Full Time','Operations Manager','c.clark@jettsfireworks.com'),(21,'Amanda Scott','Full Time','Sales Associate','a.scott@jettsfireworks.com'),(22,'Kevin King','Contracted','Warehouse Staff','k.king@jettsfireworks.com'),(23,'Sandra Wright','Full Time','Customer Service','s.wright@jettsfireworks.com'),(24,'Paul Lopez','Full Time','Sales Associate','p.lopez@jettsfireworks.com'),(25,'Rebecca Hill','Contracted','Inventory Assistant','r.hill@jettsfireworks.com');
/*!40000 ALTER TABLE `Employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Fireworks`
--

DROP TABLE IF EXISTS `Fireworks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Fireworks` (
  `FireworksID` int unsigned NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Type` varchar(45) NOT NULL,
  `Price` decimal(10,2) unsigned NOT NULL,
  `Description` mediumtext NOT NULL,
  `Classification` varchar(45) NOT NULL,
  PRIMARY KEY (`FireworksID`),
  UNIQUE KEY `FireworksID_UNIQUE` (`FireworksID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Fireworks`
--

LOCK TABLES `Fireworks` WRITE;
/*!40000 ALTER TABLE `Fireworks` DISABLE KEYS */;
INSERT INTO `Fireworks` VALUES (1,'American Thunder','Multi-shot Aerial',89.99,'36-shot cake with red, white, and blue bursts','Class C'),(2,'Dragon\'s Breath','Fountain',24.99,'Sparkling gold fountain with loud crackles','Class C'),(3,'Neon Nights','Roman Candle',12.99,'5-shot Roman candle with neon colored stars','Class C'),(4,'Shock Wave','Bottle Rocket',14.99,'Loud whistling bottle rockets with silver tail','Class C'),(5,'Golden Willow','Shell',29.99,'3-inch shell with golden willow effect','Class C'),(6,'Red Peony','Shell',27.99,'3-inch red peony shell with silver pistil','Class C'),(7,'Strobing Comet','Aerial',19.99,'Strobing comet with bright white light','Class C'),(8,'Crackling Palm','Fountain',21.99,'Fountain with crackling palm tree effect','Class C'),(9,'Silver Salute','Firecracker',8.99,'String of 100 silver salute firecrackers','Class C'),(10,'Blue Diadem','Shell',32.99,'3-inch shell with blue diadem effect','Class C'),(11,'Whistling Moon Traveler','Ground',18.99,'Whistling moon traveler with sparks','Class C'),(12,'Golden Chrysanthemum','Shell',34.99,'4-inch shell with golden chrysanthemum','Class B'),(13,'Willow in the Sky','Shell',36.99,'4-inch shell with weeping willow effect','Class B'),(14,'Crackling Diamond','Aerial',44.99,'200-shot cake with crackling diamond bursts','Class B'),(15,'Red, White & Blue','Multi-shot Aerial',79.99,'49-shot cake patriotic colors','Class C'),(16,'Purple Rain','Shell',31.99,'3-inch purple rain shell','Class C'),(17,'Strobe Flash','Roman Candle',15.99,'7-shot strobe Roman candle','Class C'),(18,'Golden Peony','Shell',29.99,'3-inch golden peony shell','Class C'),(19,'Silver Fish','Fountain',22.99,'Silver fish effect fountain','Class C'),(20,'Crackling Bouquet','Multi-shot Aerial',84.99,'24-shot crackling bouquet cake','Class C'),(21,'Green Ghost','Shell',26.99,'3-inch green ghost shell','Class C'),(22,'Golden Bees','Bees',16.99,'Tube of golden bees ground spinner','Class C'),(23,'Red Flash','Firecracker',9.99,'String of 200 red flash firecrackers','Class C'),(24,'Silver Serpent','Sparkler',6.99,'Box of 36 silver serpent sparklers','Class C'),(25,'Blue Ice','Shell',33.99,'3-inch blue ice shell','Class C'),(26,'Pink Champagne','Fountain',25.99,'Pink champagne effect fountain','Class C'),(27,'Thunder King','Multi-shot Aerial',119.99,'72-shot thunder king cake','Class B'),(28,'Golden Palm','Shell',39.99,'4-inch golden palm shell','Class B'),(29,'Crackling Mine','Repeater',49.99,'Crackling mine with multiple effects','Class B'),(30,'Neon Galaxy','Multi-shot Aerial',94.99,'48-shot neon galaxy cake','Class C'),(31,'Starburst Symphony','Shell',41.99,'4-inch multi-color starburst shell','Class B'),(32,'Lightning Fury','Bottle Rocket',16.99,'Loud lightning effect bottle rockets','Class C'),(33,'Golden Cascade','Fountain',27.99,'Golden waterfall cascade fountain','Class C'),(34,'Red Comet','Roman Candle',13.99,'6-shot red comet Roman candle','Class C'),(35,'Crackling Volcano','Repeater',54.99,'Crackling volcano repeater cake','Class B');
/*!40000 ALTER TABLE `Fireworks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Inventory`
--

DROP TABLE IF EXISTS `Inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Inventory` (
  `InventoryID` int unsigned NOT NULL AUTO_INCREMENT,
  `Fireworks_FireworksID` int unsigned NOT NULL,
  `Bunkers_BunkerID` int unsigned NOT NULL,
  `Quantity` int unsigned NOT NULL,
  PRIMARY KEY (`InventoryID`),
  UNIQUE KEY `InventoryID_UNIQUE` (`InventoryID`),
  KEY `fk_Inventory_Fireworks1_idx` (`Fireworks_FireworksID`),
  KEY `fk_Inventory_Bunkers1_idx` (`Bunkers_BunkerID`),
  CONSTRAINT `fk_Inventory_Bunkers1` FOREIGN KEY (`Bunkers_BunkerID`) REFERENCES `Bunkers` (`BunkerID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Inventory_Fireworks1` FOREIGN KEY (`Fireworks_FireworksID`) REFERENCES `Fireworks` (`FireworksID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Inventory`
--

LOCK TABLES `Inventory` WRITE;
/*!40000 ALTER TABLE `Inventory` DISABLE KEYS */;
INSERT INTO `Inventory` VALUES (1,1,1,25),(2,2,1,40),(3,3,1,60),(4,4,1,100),(5,5,1,30),(6,6,1,35),(7,7,1,45),(8,8,1,50),(9,9,1,200),(10,10,1,25),(11,11,2,40),(12,12,3,15),(13,13,3,12),(14,14,3,10),(15,15,2,18),(16,16,2,22),(17,17,2,35),(18,18,2,28),(19,19,2,32),(20,20,2,20),(21,21,4,25),(22,22,4,40),(23,23,4,150),(24,24,4,80),(25,25,4,20),(26,26,4,30),(27,27,5,8),(28,28,5,10),(29,29,5,12),(30,30,4,15),(31,1,6,20),(32,2,6,30),(33,3,6,50),(34,4,6,80),(35,5,6,25),(36,6,7,10),(37,7,6,35),(38,8,6,40),(39,9,6,150),(40,10,6,20),(41,11,8,30),(42,12,7,8),(43,13,7,6),(44,14,5,5),(45,15,8,12),(46,16,8,18),(47,17,8,25),(48,18,8,20),(49,19,8,25),(50,20,8,15),(51,31,10,6),(52,32,9,45),(53,33,9,25),(54,34,9,60),(55,35,10,8),(56,30,9,20),(57,25,11,18),(58,26,11,22),(59,27,13,7),(60,28,13,9),(61,29,13,10),(62,30,11,12),(63,31,13,5),(64,32,12,50),(65,33,12,30),(66,34,12,55),(67,35,13,6),(68,1,14,15),(69,2,14,25),(70,3,14,40),(71,4,14,70),(72,5,14,20),(73,6,15,18),(74,7,14,30),(75,8,14,35),(76,9,14,120),(77,10,15,15),(78,11,15,25),(79,12,10,7),(80,13,10,5);
/*!40000 ALTER TABLE `Inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `OrderItems`
--

DROP TABLE IF EXISTS `OrderItems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `OrderItems` (
  `OrderItemsId` int unsigned NOT NULL AUTO_INCREMENT,
  `Orders_OrderId` int unsigned NOT NULL,
  `Fireworks_FireworksID` int unsigned NOT NULL,
  `Quantity` int unsigned NOT NULL,
  `Price` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`OrderItemsId`),
  UNIQUE KEY `OrderItemsId_UNIQUE` (`OrderItemsId`),
  KEY `fk_OrderItems_Orders1_idx` (`Orders_OrderId`),
  KEY `fk_OrderItems_Fireworks1_idx` (`Fireworks_FireworksID`),
  CONSTRAINT `fk_OrderItems_Fireworks1` FOREIGN KEY (`Fireworks_FireworksID`) REFERENCES `Fireworks` (`FireworksID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_OrderItems_Orders1` FOREIGN KEY (`Orders_OrderId`) REFERENCES `Orders` (`OrderId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `OrderItems`
--

LOCK TABLES `OrderItems` WRITE;
/*!40000 ALTER TABLE `OrderItems` DISABLE KEYS */;
INSERT INTO `OrderItems` VALUES (1,1,1,1,89.99),(2,1,4,2,14.99),(3,1,9,3,8.99),(4,2,1,2,89.99),(5,2,15,3,79.99),(6,2,20,1,84.99),(7,2,25,2,33.99),(8,2,30,1,94.99),(9,3,1,1,89.99),(10,4,2,1,24.99),(11,4,3,1,12.99),(12,4,7,1,19.99),(13,4,9,1,8.99),(14,5,1,5,89.99),(15,5,12,3,34.99),(16,5,14,2,44.99),(17,5,20,4,84.99),(18,5,27,2,119.99),(19,5,29,1,49.99),(20,6,5,2,29.99),(21,6,6,1,27.99),(22,6,11,1,18.99),(23,7,9,5,8.99),(24,8,8,1,21.99),(25,8,10,1,32.99),(26,8,24,2,6.99),(27,9,1,3,89.99),(28,9,15,2,79.99),(29,9,20,2,84.99),(30,9,30,3,94.99),(31,10,23,2,9.99),(32,10,24,1,6.99),(33,10,9,1,8.99),(34,11,1,1,89.99),(35,12,2,1,24.99),(36,12,3,1,12.99),(37,12,9,2,8.99),(38,13,1,1,89.99),(39,13,4,2,14.99),(40,13,24,1,6.99),(41,14,5,1,29.99),(42,14,6,1,27.99),(43,14,9,1,8.99),(44,15,1,2,89.99),(45,15,12,5,34.99),(46,15,14,3,44.99),(47,15,20,2,84.99),(48,16,9,5,8.99),(49,17,1,1,89.99),(50,17,4,2,14.99),(51,17,9,3,8.99),(52,18,1,1,89.99),(53,19,5,2,29.99),(54,19,6,1,27.99),(55,19,11,1,18.99),(56,20,1,2,89.99),(57,20,15,2,79.99),(58,20,20,1,84.99),(59,20,30,1,94.99),(60,21,2,1,24.99),(61,21,3,1,12.99),(62,21,7,1,19.99),(63,21,9,1,8.99),(64,22,1,1,89.99),(65,23,1,1,89.99),(66,23,4,2,14.99),(67,23,9,3,8.99),(68,24,9,5,8.99),(69,25,1,3,89.99),(70,25,12,4,34.99),(71,25,20,2,84.99),(72,26,5,2,29.99),(73,26,6,1,27.99),(74,26,11,1,18.99),(75,27,1,1,89.99),(76,28,1,2,89.99),(77,28,12,3,34.99),(78,28,14,2,44.99),(79,28,20,4,84.99),(80,29,2,1,24.99),(81,29,3,1,12.99),(82,29,24,2,6.99),(83,30,1,1,89.99),(84,30,4,2,14.99),(85,30,9,3,8.99),(86,31,1,4,89.99),(87,31,12,5,34.99),(88,31,14,3,44.99),(89,31,27,2,119.99),(90,32,9,5,8.99),(91,33,8,1,21.99),(92,33,10,1,32.99),(93,33,24,2,6.99),(94,34,23,2,9.99),(95,34,24,1,6.99),(96,34,9,1,8.99),(97,35,1,2,89.99),(98,35,15,3,79.99),(99,35,20,2,84.99),(100,35,30,3,94.99),(101,36,1,1,89.99),(102,37,5,2,29.99),(103,37,6,1,27.99),(104,37,11,1,18.99),(105,38,2,1,24.99),(106,38,3,1,12.99),(107,38,7,1,19.99),(108,38,9,1,8.99),(109,39,1,1,89.99),(110,39,4,2,14.99),(111,39,9,3,8.99),(112,40,9,5,8.99),(113,41,31,2,41.99),(114,41,32,3,16.99),(115,41,33,1,27.99),(116,41,34,2,13.99),(117,42,35,1,54.99),(118,42,30,1,94.99),(119,42,25,1,33.99),(120,43,12,4,34.99),(121,43,13,3,36.99),(122,43,14,2,44.99),(123,43,27,1,119.99),(124,43,28,2,39.99),(125,44,1,1,89.99),(126,44,4,1,14.99),(127,44,9,2,8.99),(128,45,15,2,79.99),(129,45,20,1,84.99),(130,45,30,1,94.99),(131,46,1,1,89.99),(132,47,1,1,89.99),(133,47,4,2,14.99),(134,47,9,3,8.99),(135,48,1,2,89.99),(136,48,15,3,79.99),(137,48,20,2,84.99),(138,49,8,1,21.99),(139,49,10,1,32.99),(140,49,24,2,6.99),(141,50,12,2,34.99),(142,50,14,3,44.99),(143,50,20,2,84.99),(144,51,1,3,89.99),(145,51,12,4,34.99),(146,51,27,2,119.99),(147,51,29,1,49.99),(148,52,5,1,29.99),(149,52,6,1,27.99),(150,52,11,1,18.99),(151,53,1,1,89.99),(152,53,7,1,19.99),(153,53,24,1,6.99),(154,54,9,5,8.99),(155,55,1,2,89.99),(156,55,12,3,34.99),(157,55,20,2,84.99),(158,55,30,3,94.99),(159,56,5,2,29.99),(160,56,6,1,27.99),(161,56,11,1,18.99),(162,57,12,2,34.99),(163,57,13,3,36.99),(164,57,14,1,44.99),(165,58,1,1,89.99),(166,59,1,1,89.99),(167,59,4,2,14.99),(168,59,9,3,8.99),(169,60,2,1,24.99),(170,60,3,1,12.99),(171,60,7,1,19.99),(172,60,9,1,8.99),(173,1,5,1,29.99),(174,2,8,2,21.99),(175,3,2,1,24.99),(176,4,5,1,29.99),(177,5,5,3,29.99),(178,6,8,1,21.99),(179,7,2,1,24.99),(180,8,5,1,29.99);
/*!40000 ALTER TABLE `OrderItems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Orders`
--

DROP TABLE IF EXISTS `Orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Orders` (
  `OrderId` int unsigned NOT NULL AUTO_INCREMENT,
  `Customers_CustomerID` int unsigned NOT NULL,
  `Employees_EmployeeID` int unsigned NOT NULL,
  `OrderDate` date NOT NULL,
  `TotalCost` decimal(10,2) unsigned NOT NULL,
  PRIMARY KEY (`OrderId`),
  UNIQUE KEY `OrderId_UNIQUE` (`OrderId`),
  KEY `fk_Orders_Customers_idx` (`Customers_CustomerID`),
  KEY `fk_Orders_Employees1_idx` (`Employees_EmployeeID`),
  CONSTRAINT `fk_Orders_Customers` FOREIGN KEY (`Customers_CustomerID`) REFERENCES `Customers` (`CustomerID`) ON UPDATE CASCADE,
  CONSTRAINT `fk_Orders_Employees1` FOREIGN KEY (`Employees_EmployeeID`) REFERENCES `Employees` (`EmployeeID`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Orders`
--

LOCK TABLES `Orders` WRITE;
/*!40000 ALTER TABLE `Orders` DISABLE KEYS */;
INSERT INTO `Orders` VALUES (1,1,1,'2024-06-15',156.97),(2,3,2,'2024-06-16',489.95),(3,5,4,'2024-06-17',89.99),(4,2,1,'2024-06-18',67.96),(5,6,5,'2024-06-19',1248.85),(6,4,2,'2024-06-20',112.97),(7,7,4,'2024-06-21',45.97),(8,8,1,'2024-06-22',78.96),(9,10,5,'2024-06-23',959.92),(10,9,2,'2024-06-24',34.97),(11,11,4,'2024-06-25',89.99),(12,12,1,'2024-06-26',56.97),(13,13,2,'2024-06-27',123.95),(14,14,4,'2024-06-28',67.96),(15,16,5,'2024-06-29',879.93),(16,15,1,'2024-06-30',45.97),(17,17,2,'2024-07-01',156.97),(18,18,4,'2024-07-02',89.99),(19,19,1,'2024-07-03',112.97),(20,20,2,'2024-07-04',456.94),(21,21,4,'2024-07-05',67.96),(22,22,1,'2024-07-06',89.99),(23,23,2,'2024-07-07',156.97),(24,24,4,'2024-07-08',45.97),(25,25,5,'2024-07-09',689.95),(26,1,1,'2024-07-10',112.97),(27,2,2,'2024-07-11',89.99),(28,3,4,'2024-07-12',789.93),(29,4,1,'2024-07-13',56.97),(30,5,2,'2024-07-14',156.97),(31,6,5,'2024-07-15',1099.91),(32,7,4,'2024-07-16',45.97),(33,8,1,'2024-07-17',78.96),(34,9,2,'2024-07-18',34.97),(35,10,5,'2024-07-19',849.94),(36,11,4,'2024-07-20',89.99),(37,12,1,'2024-07-21',112.97),(38,13,2,'2024-07-22',67.96),(39,14,4,'2024-07-23',156.97),(40,15,1,'2024-07-24',45.97),(41,26,3,'2024-07-25',178.97),(42,27,6,'2024-07-26',94.95),(43,28,7,'2024-07-27',689.93),(44,29,8,'2024-07-28',123.96),(45,99,9,'2024-07-29',234.94),(46,1,10,'2024-07-30',89.99),(47,2,11,'2024-07-31',156.97),(48,3,12,'2024-08-01',589.95),(49,4,13,'2024-08-02',78.96),(50,5,14,'2024-08-03',345.97),(51,6,15,'2024-08-04',998.92),(52,7,16,'2024-08-05',67.97),(53,8,17,'2024-08-06',112.99),(54,9,18,'2024-08-07',45.97),(55,10,19,'2024-08-08',789.94),(56,11,20,'2024-08-09',123.96),(57,12,21,'2024-08-10',234.95),(58,13,22,'2024-08-11',89.99),(59,14,23,'2024-08-12',156.97),(60,15,24,'2024-08-13',67.96);
/*!40000 ALTER TABLE `Orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PurchaseHistory`
--

DROP TABLE IF EXISTS `PurchaseHistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseHistory` (
  `HistoryID` int unsigned NOT NULL AUTO_INCREMENT,
  `Orders_OrderId` int unsigned NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY (`HistoryID`),
  UNIQUE KEY `HistoryID_UNIQUE` (`HistoryID`),
  KEY `fk_PurchaseHistory_Orders1_idx` (`Orders_OrderId`),
  CONSTRAINT `fk_PurchaseHistory_Orders1` FOREIGN KEY (`Orders_OrderId`) REFERENCES `Orders` (`OrderId`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseHistory`
--

LOCK TABLES `PurchaseHistory` WRITE;
/*!40000 ALTER TABLE `PurchaseHistory` DISABLE KEYS */;
INSERT INTO `PurchaseHistory` VALUES (1,1,'2024-06-15'),(2,2,'2024-06-16'),(3,3,'2024-06-17'),(4,4,'2024-06-18'),(5,5,'2024-06-19'),(6,6,'2024-06-20'),(7,7,'2024-06-21'),(8,8,'2024-06-22'),(9,9,'2024-06-23'),(10,10,'2024-06-24'),(11,11,'2024-06-25'),(12,12,'2024-06-26'),(13,13,'2024-06-27'),(14,14,'2024-06-28'),(15,15,'2024-06-29'),(16,16,'2024-06-30'),(17,17,'2024-07-01'),(18,18,'2024-07-02'),(19,19,'2024-07-03'),(20,20,'2024-07-04'),(21,21,'2024-07-05'),(22,22,'2024-07-06'),(23,23,'2024-07-07'),(24,24,'2024-07-08'),(25,25,'2024-07-09'),(26,26,'2024-07-10'),(27,27,'2024-07-11'),(28,28,'2024-07-12'),(29,29,'2024-07-13'),(30,30,'2024-07-14'),(31,31,'2024-07-15'),(32,32,'2024-07-16'),(33,33,'2024-07-17'),(34,34,'2024-07-18'),(35,35,'2024-07-19'),(36,36,'2024-07-20'),(37,37,'2024-07-21'),(38,38,'2024-07-22'),(39,39,'2024-07-23'),(40,40,'2024-07-24'),(41,41,'2024-07-25'),(42,42,'2024-07-26'),(43,43,'2024-07-27'),(44,44,'2024-07-28'),(45,45,'2024-07-29'),(46,46,'2024-07-30'),(47,47,'2024-07-31'),(48,48,'2024-08-01'),(49,49,'2024-08-02'),(50,50,'2024-08-03'),(51,51,'2024-08-04'),(52,52,'2024-08-05'),(53,53,'2024-08-06'),(54,54,'2024-08-07'),(55,55,'2024-08-08'),(56,56,'2024-08-09'),(57,57,'2024-08-10'),(58,58,'2024-08-11'),(59,59,'2024-08-12'),(60,60,'2024-08-13');
/*!40000 ALTER TABLE `PurchaseHistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-10 14:39:05
