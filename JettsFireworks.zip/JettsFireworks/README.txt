﻿Jetts Fireworks database includes data for customers, employees, orders, order details, fireworks, inventory, and where the product is stored. All this data was generated using a LLM to make it easier to cross populate tables that reference others. 


I had to most problems trying to decide how my tables should interact with each other like the cascade and im still not sure if i got it right. I also had some trouble actually populating my data as the LLM were not cooperating in generating the data in a way i could use. 


I think I will get around a B because I did level 2 for both the schema and queries but I left out the front end. I also am not sure if my logic is correct so maybe the lower end of a B.